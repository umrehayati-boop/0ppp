package com.example.thanosworld.items;

import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.CompoundNBT;
import net.minecraft.potion.EffectInstance;
import net.minecraft.potion.Effects;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.world.World;

import javax.annotation.Nullable;
import java.util.List;

public class InfinityGauntletItem extends Item {

    public InfinityGauntletItem() {
        super(new Item.Properties()
                .tab(net.minecraft.item.ItemGroup.TAB_MISC)
                .stacksTo(1)
                .rarity(net.minecraft.item.Rarity.EPIC));
    }

    @Override
    public ActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
        if (!world.isClientSide) {
            ItemStack gauntlet = player.getItemInHand(hand);
            CompoundNBT nbt = gauntlet.getOrCreateTag();
            int stonesCount = nbt.getInt("stones");

            if (stonesCount == 0) {
                player.sendMessage(new StringTextComponent(
                        TextFormatting.GOLD + "Sonsuzluk Eldiveni boş! Taş tak: /taktas <tas>"),
                        player.getUUID());
                return ActionResult.fail(gauntlet);
            }

            // Aktif taşlara göre güç ver
            boolean hasSpace = nbt.getBoolean("space");
            boolean hasMind = nbt.getBoolean("mind");
            boolean hasReality = nbt.getBoolean("reality");
            boolean hasPower = nbt.getBoolean("power");
            boolean hasTime = nbt.getBoolean("time");
            boolean hasSoul = nbt.getBoolean("soul");

            if (hasSpace) player.addEffect(new EffectInstance(Effects.MOVEMENT_SPEED, 2400, 4));
            if (hasMind) player.addEffect(new EffectInstance(Effects.NIGHT_VISION, 2400, 0));
            if (hasReality) player.addEffect(new EffectInstance(Effects.INVISIBILITY, 1200, 0));
            if (hasPower) player.addEffect(new EffectInstance(Effects.DAMAGE_BOOST, 2400, 5));
            if (hasTime) player.addEffect(new EffectInstance(Effects.HASTE, 2400, 4));
            if (hasSoul) player.addEffect(new EffectInstance(Effects.ABSORPTION, 2400, 9));

            // Her zaman hasar direnci
            player.addEffect(new EffectInstance(Effects.DAMAGE_RESISTANCE, 2400, stonesCount));

            // 6 taş varsa - TAM GÜÇ!
            if (stonesCount >= 6) {
                player.addEffect(new EffectInstance(Effects.DAMAGE_BOOST, 2400, 9));
                player.addEffect(new EffectInstance(Effects.MOVEMENT_SPEED, 2400, 6));
                player.addEffect(new EffectInstance(Effects.DAMAGE_RESISTANCE, 2400, 9));
                player.addEffect(new EffectInstance(Effects.REGENERATION, 2400, 4));
                player.addEffect(new EffectInstance(Effects.ABSORPTION, 2400, 19));
                player.sendMessage(new StringTextComponent(
                        TextFormatting.GOLD + "★★★ TAM GÜÇ! Evrenin yarısını silebilirsin! ★★★"),
                        player.getUUID());
            } else {
                player.sendMessage(new StringTextComponent(
                        TextFormatting.GOLD + "Eldiven aktif! " + stonesCount + "/6 taş takılı."),
                        player.getUUID());
            }
        }
        return ActionResult.success(player.getItemInHand(hand));
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable World world, List<ITextComponent> tooltip, ITooltipFlag flag) {
        tooltip.add(new StringTextComponent(TextFormatting.GOLD + "✦ Sonsuzluk Eldiveni ✦"));
        CompoundNBT nbt = stack.getTag();
        if (nbt != null) {
            int stones = nbt.getInt("stones");
            tooltip.add(new StringTextComponent(TextFormatting.YELLOW + "Takılı Taşlar: " + stones + "/6"));
            if (nbt.getBoolean("space")) tooltip.add(new StringTextComponent(TextFormatting.BLUE + "  ✔ Uzay Taşı"));
            if (nbt.getBoolean("mind")) tooltip.add(new StringTextComponent(TextFormatting.YELLOW + "  ✔ Zihin Taşı"));
            if (nbt.getBoolean("reality")) tooltip.add(new StringTextComponent(TextFormatting.RED + "  ✔ Gerçeklik Taşı"));
            if (nbt.getBoolean("power")) tooltip.add(new StringTextComponent(TextFormatting.DARK_PURPLE + "  ✔ Güç Taşı"));
            if (nbt.getBoolean("time")) tooltip.add(new StringTextComponent(TextFormatting.GREEN + "  ✔ Zaman Taşı"));
            if (nbt.getBoolean("soul")) tooltip.add(new StringTextComponent(TextFormatting.GOLD + "  ✔ Ruh Taşı"));
        } else {
            tooltip.add(new StringTextComponent(TextFormatting.GRAY + "Boş - Taş takılmamış"));
        }
        tooltip.add(new StringTextComponent(TextFormatting.GRAY + "Sağ tık: Güçleri aktif et"));
        tooltip.add(new StringTextComponent(TextFormatting.GRAY + "/taktas <tas_adi> ile taş tak"));
    }
}
