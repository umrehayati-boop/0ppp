package com.example.thanosworld.items;

import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.EffectInstance;
import net.minecraft.potion.Effects;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.world.World;

import javax.annotation.Nullable;
import java.util.List;

public class InfinityStoneItem extends Item {

    private final int stoneType;
    
    private static final String[] STONE_NAMES = {
        "Uzay Taşı", "Zihin Taşı", "Gerçeklik Taşı",
        "Güç Taşı", "Zaman Taşı", "Ruh Taşı"
    };
    
    private static final TextFormatting[] STONE_COLORS = {
        TextFormatting.BLUE, TextFormatting.YELLOW, TextFormatting.RED,
        TextFormatting.DARK_PURPLE, TextFormatting.GREEN, TextFormatting.GOLD
    };

    public InfinityStoneItem(int stoneType) {
        super(new Item.Properties()
                .tab(net.minecraft.item.ItemGroup.TAB_MISC)
                .stacksTo(1)
                .rarity(net.minecraft.item.Rarity.EPIC));
        this.stoneType = stoneType;
    }

    @Override
    public ActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
        if (!world.isClientSide) {
            applyStoneEffect(player);
            player.sendMessage(new StringTextComponent(
                    STONE_COLORS[stoneType] + "★ " + STONE_NAMES[stoneType] + " gücü aktif! ★"),
                    player.getUUID());
        }
        return ActionResult.success(player.getItemInHand(hand));
    }

    private void applyStoneEffect(PlayerEntity player) {
        switch (stoneType) {
            case 0: // Uzay Taşı - Hız
                player.addEffect(new EffectInstance(Effects.MOVEMENT_SPEED, 1200, 4));
                player.addEffect(new EffectInstance(Effects.JUMP, 1200, 4));
                break;
            case 1: // Zihin Taşı - Zeka/Görüş
                player.addEffect(new EffectInstance(Effects.NIGHT_VISION, 1200, 0));
                player.addEffect(new EffectInstance(Effects.GLOWING, 1200, 0));
                break;
            case 2: // Gerçeklik Taşı - Görünmezlik
                player.addEffect(new EffectInstance(Effects.INVISIBILITY, 600, 0));
                player.addEffect(new EffectInstance(Effects.DAMAGE_RESISTANCE, 600, 2));
                break;
            case 3: // Güç Taşı - Güç
                player.addEffect(new EffectInstance(Effects.DAMAGE_BOOST, 1200, 4));
                player.addEffect(new EffectInstance(Effects.DAMAGE_RESISTANCE, 1200, 3));
                break;
            case 4: // Zaman Taşı - Yavaşlatma kaldırır, hızlandırır
                player.addEffect(new EffectInstance(Effects.MOVEMENT_SPEED, 1200, 3));
                player.addEffect(new EffectInstance(Effects.HASTE, 1200, 3));
                player.removeEffect(Effects.MOVEMENT_SLOWDOWN);
                break;
            case 5: // Ruh Taşı - Yenilmezlik
                player.addEffect(new EffectInstance(Effects.ABSORPTION, 1200, 9));
                player.addEffect(new EffectInstance(Effects.REGENERATION, 600, 2));
                break;
        }
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable World world, List<ITextComponent> tooltip, ITooltipFlag flag) {
        tooltip.add(new StringTextComponent(STONE_COLORS[stoneType] + "✦ Sonsuzluk Taşı ✦"));
        tooltip.add(new StringTextComponent(TextFormatting.GRAY + "Sağ tık: Taşın gücünü kullan"));
        switch (stoneType) {
            case 0: tooltip.add(new StringTextComponent(TextFormatting.BLUE + "Süper Hız ve Zıplama")); break;
            case 1: tooltip.add(new StringTextComponent(TextFormatting.YELLOW + "Gece Görüşü ve Aydınlanma")); break;
            case 2: tooltip.add(new StringTextComponent(TextFormatting.RED + "Görünmezlik ve Direnç")); break;
            case 3: tooltip.add(new StringTextComponent(TextFormatting.DARK_PURPLE + "Süper Güç ve Hasar Direnci")); break;
            case 4: tooltip.add(new StringTextComponent(TextFormatting.GREEN + "Zaman Hızlanması ve El Çabukluğu")); break;
            case 5: tooltip.add(new StringTextComponent(TextFormatting.GOLD + "Yenilmezlik ve Yenilenme")); break;
        }
        tooltip.add(new StringTextComponent(TextFormatting.DARK_GRAY + "Eldivene tak: /taktas <tas_adi>"));
    }
}
