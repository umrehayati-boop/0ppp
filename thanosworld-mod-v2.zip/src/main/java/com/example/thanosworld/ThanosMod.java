package com.example.thanosworld;

import com.example.thanosworld.blocks.ModBlocks;
import com.example.thanosworld.events.ThanosEventHandler;
import com.example.thanosworld.items.ModItems;
import com.example.thanosworld.world.ThanosDimension;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Mod(ThanosMod.MOD_ID)
public class ThanosMod {
    public static final String MOD_ID = "thanosworld";
    public static final Logger LOGGER = LogManager.getLogger();

    public ThanosMod() {
        ModItems.ITEMS.register(FMLJavaModLoadingContext.get().getModEventBus());
        ModBlocks.BLOCKS.register(FMLJavaModLoadingContext.get().getModEventBus());
        ModBlocks.BLOCK_ITEMS.register(FMLJavaModLoadingContext.get().getModEventBus());

        FMLJavaModLoadingContext.get().getModEventBus().addListener(this::setup);
        MinecraftForge.EVENT_BUS.register(ThanosEventHandler.class);
    }

    private void setup(final FMLCommonSetupEvent event) {
        ThanosDimension.register();
        LOGGER.info("==============================");
        LOGGER.info("  Thanos World Mod Yüklendi!");
        LOGGER.info("  Sonsuzluk Taşları Hazır!");
        LOGGER.info("==============================");
    }
}
