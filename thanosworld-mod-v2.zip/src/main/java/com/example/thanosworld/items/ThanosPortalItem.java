package com.example.thanosworld.items;

import com.example.thanosworld.world.ThanosDimension;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.particles.ParticleTypes;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvents;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.world.World;
import net.minecraft.world.server.ServerWorld;

import javax.annotation.Nullable;
import java.util.List;

public class ThanosPortalItem extends Item {

    public ThanosPortalItem() {
        super(new Item.Properties()
                .tab(net.minecraft.item.ItemGroup.TAB_MISC)
                .stacksTo(1));
    }

    @Override
    public ActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
        if (!world.isClientSide) {
            ServerPlayerEntity serverPlayer = (ServerPlayerEntity) player;

            // Mor partikül efekti
            ServerWorld serverWorld = (ServerWorld) world;
            for (int i = 0; i < 30; i++) {
                serverWorld.sendParticles(ParticleTypes.DRAGON_BREATH,
                        player.getX(), player.getY() + 1, player.getZ(),
                        1, 0.5, 0.5, 0.5, 0.1);
            }

            // Portal sesi
            world.playSound(null, player.blockPosition(),
                    SoundEvents.END_PORTAL_SPAWN, SoundCategory.PLAYERS, 1.0f, 0.5f);

            player.sendMessage(new StringTextComponent(
                    TextFormatting.DARK_PURPLE + "★ " +
                    TextFormatting.LIGHT_PURPLE + "Portal açılıyor... Thanos Dünyasına hoş geldin!" +
                    TextFormatting.DARK_PURPLE + " ★"), player.getUUID());

            // Thanos dünyasına teleport et
            ThanosDimension.teleportToThanos(serverPlayer);

        } else {
            // Client tarafında partikül efekti
            for (int i = 0; i < 10; i++) {
                world.addParticle(ParticleTypes.DRAGON_BREATH,
                        player.getX() + (Math.random()-0.5),
                        player.getY() + Math.random()*2,
                        player.getZ() + (Math.random()-0.5),
                        0, 0.1, 0);
            }
        }

        return ActionResult.success(player.getItemInHand(hand));
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable World world, List<ITextComponent> tooltip, ITooltipFlag flag) {
        tooltip.add(new StringTextComponent(TextFormatting.DARK_PURPLE + "Thanos'un Portalı!"));
        tooltip.add(new StringTextComponent(TextFormatting.GRAY + "Sağ tık: Thanos Dünyasına ışınlan"));
        tooltip.add(new StringTextComponent(TextFormatting.YELLOW + "Portal kapandıktan sonra dönmek için"));
        tooltip.add(new StringTextComponent(TextFormatting.YELLOW + "tekrar kullan!"));
    }
}
