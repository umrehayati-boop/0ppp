package com.example.thanosworld.items;

import com.example.thanosworld.ThanosMod;
import net.minecraft.item.Item;
import net.minecraftforge.fml.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;

public class ModItems {

    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, ThanosMod.MOD_ID);

    // Thanos Portalı
    public static final RegistryObject<Item> THANOS_PORTAL =
            ITEMS.register("thanos_portal", ThanosPortalItem::new);

    // Sonsuzluk Taşları
    public static final RegistryObject<Item> SPACE_STONE =
            ITEMS.register("space_stone", () -> new InfinityStoneItem(0));
    public static final RegistryObject<Item> MIND_STONE =
            ITEMS.register("mind_stone", () -> new InfinityStoneItem(1));
    public static final RegistryObject<Item> REALITY_STONE =
            ITEMS.register("reality_stone", () -> new InfinityStoneItem(2));
    public static final RegistryObject<Item> POWER_STONE =
            ITEMS.register("power_stone", () -> new InfinityStoneItem(3));
    public static final RegistryObject<Item> TIME_STONE =
            ITEMS.register("time_stone", () -> new InfinityStoneItem(4));
    public static final RegistryObject<Item> SOUL_STONE =
            ITEMS.register("soul_stone", () -> new InfinityStoneItem(5));

    // Sonsuzluk Eldiveni
    public static final RegistryObject<Item> INFINITY_GAUNTLET =
            ITEMS.register("infinity_gauntlet", InfinityGauntletItem::new);
}
