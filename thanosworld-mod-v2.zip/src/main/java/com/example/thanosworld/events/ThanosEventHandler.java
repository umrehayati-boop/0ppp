package com.example.thanosworld.events;

import com.example.thanosworld.ThanosMod;
import com.example.thanosworld.items.ModItems;
import com.example.thanosworld.world.ThanosDimension;
import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.command.CommandSource;
import net.minecraft.command.Commands;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.CompoundNBT;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.util.text.TextFormatting;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.HashMap;
import java.util.Map;

@Mod.EventBusSubscriber(modid = ThanosMod.MOD_ID)
public class ThanosEventHandler {

    // Taş adı -> NBT key mapping
    private static final Map<String, String[]> STONE_MAP = new HashMap<>();
    static {
        STONE_MAP.put("uzay", new String[]{"space", "space_stone"});
        STONE_MAP.put("zihin", new String[]{"mind", "mind_stone"});
        STONE_MAP.put("gerceklik", new String[]{"reality", "reality_stone"});
        STONE_MAP.put("guc", new String[]{"power", "power_stone"});
        STONE_MAP.put("zaman", new String[]{"time", "time_stone"});
        STONE_MAP.put("ruh", new String[]{"soul", "soul_stone"});
        STONE_MAP.put("space", new String[]{"space", "space_stone"});
        STONE_MAP.put("mind", new String[]{"mind", "mind_stone"});
        STONE_MAP.put("reality", new String[]{"reality", "reality_stone"});
        STONE_MAP.put("power", new String[]{"power", "power_stone"});
        STONE_MAP.put("time", new String[]{"time", "time_stone"});
        STONE_MAP.put("soul", new String[]{"soul", "soul_stone"});
    }

    @SubscribeEvent
    public static void onRegisterCommands(RegisterCommandsEvent event) {
        CommandDispatcher<CommandSource> dispatcher = event.getDispatcher();

        // /taktas <tas_adi> - eldivenine taş tak
        dispatcher.register(Commands.literal("taktas")
                .then(Commands.argument("tas", com.mojang.brigadier.arguments.StringArgumentType.word())
                        .executes(ctx -> {
                            if (ctx.getSource().getEntity() instanceof ServerPlayerEntity) {
                                ServerPlayerEntity player = (ServerPlayerEntity) ctx.getSource().getEntity();
                                String stone = com.mojang.brigadier.arguments.StringArgumentType.getString(ctx, "tas").toLowerCase();
                                attachStoneToGauntlet(player, stone);
                            }
                            return 1;
                        })));

        // /thanosworld - yardım
        dispatcher.register(Commands.literal("thanosworld")
                .executes(ctx -> {
                    CommandSource src = ctx.getSource();
                    src.sendSuccess(new StringTextComponent(TextFormatting.GOLD + "=== Thanos World Komutları ==="), false);
                    src.sendSuccess(new StringTextComponent(TextFormatting.YELLOW + "/taktas <tas>" + TextFormatting.WHITE + " - Eldivenine taş tak"), false);
                    src.sendSuccess(new StringTextComponent(TextFormatting.AQUA + "Taş İsimleri:"), false);
                    src.sendSuccess(new StringTextComponent(TextFormatting.BLUE + "  uzay/space"), false);
                    src.sendSuccess(new StringTextComponent(TextFormatting.YELLOW + "  zihin/mind"), false);
                    src.sendSuccess(new StringTextComponent(TextFormatting.RED + "  gerceklik/reality"), false);
                    src.sendSuccess(new StringTextComponent(TextFormatting.DARK_PURPLE + "  guc/power"), false);
                    src.sendSuccess(new StringTextComponent(TextFormatting.GREEN + "  zaman/time"), false);
                    src.sendSuccess(new StringTextComponent(TextFormatting.GOLD + "  ruh/soul"), false);
                    src.sendSuccess(new StringTextComponent(TextFormatting.GRAY + "Portal ile Thanos Dünyasına git!"), false);
                    return 1;
                }));
    }

    private static void attachStoneToGauntlet(ServerPlayerEntity player, String stoneName) {
        // Envanterde eldiven ara
        for (ItemStack stack : player.inventory.items) {
            if (stack.getItem() == ModItems.INFINITY_GAUNTLET.get()) {
                String[] mapping = STONE_MAP.get(stoneName);
                if (mapping == null) {
                    player.sendMessage(new StringTextComponent(
                            TextFormatting.RED + "Geçersiz taş adı! /thanosworld komutuna bak."),
                            player.getUUID());
                    return;
                }

                // Envanterde bu taş var mı?
                String nbtKey = mapping[0];
                String itemId = mapping[1];
                boolean hasStone = false;

                for (ItemStack invStack : player.inventory.items) {
                    if (invStack.getItem().getRegistryName() != null &&
                        invStack.getItem().getRegistryName().getPath().equals(itemId)) {
                        hasStone = true;
                        invStack.shrink(1); // Taşı tüket
                        break;
                    }
                }

                if (!hasStone) {
                    player.sendMessage(new StringTextComponent(
                            TextFormatting.RED + "Envanterinde bu taş yok!"),
                            player.getUUID());
                    return;
                }

                CompoundNBT nbt = stack.getOrCreateTag();
                if (nbt.getBoolean(nbtKey)) {
                    player.sendMessage(new StringTextComponent(
                            TextFormatting.YELLOW + "Bu taş zaten takılı!"),
                            player.getUUID());
                    return;
                }

                nbt.putBoolean(nbtKey, true);
                nbt.putInt("stones", nbt.getInt("stones") + 1);
                stack.setTag(nbt);

                player.sendMessage(new StringTextComponent(
                        TextFormatting.GOLD + "✦ " + stoneName + " taşı eldivenine takıldı! (" +
                        nbt.getInt("stones") + "/6)"),
                        player.getUUID());

                if (nbt.getInt("stones") >= 6) {
                    player.sendMessage(new StringTextComponent(
                            TextFormatting.GOLD + "★★★ TÜM TAŞLAR TAKILI! Sonsuzluk Eldiveni tam güçte! ★★★"),
                            player.getUUID());
                }
                return;
            }
        }

        player.sendMessage(new StringTextComponent(
                TextFormatting.RED + "Envanterinde Sonsuzluk Eldiveni yok!"),
                player.getUUID());
    }
}
