package com.example.thanosworld.blocks;

import com.example.thanosworld.ThanosMod;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraftforge.fml.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;

public class ModBlocks {

    public static final DeferredRegister<Block> BLOCKS =
            DeferredRegister.create(ForgeRegistries.BLOCKS, ThanosMod.MOD_ID);

    public static final DeferredRegister<Item> BLOCK_ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, ThanosMod.MOD_ID);

    public static final RegistryObject<Block> THANOS_PORTAL_BLOCK =
            BLOCKS.register("thanos_portal_block",
                    () -> new Block(Block.Properties.of(Material.GLASS)
                            .strength(-1.0f, 3600000.0f)
                            .lightLevel(state -> 15)
                            .noDrops()));

    public static final RegistryObject<Item> THANOS_PORTAL_BLOCK_ITEM =
            BLOCK_ITEMS.register("thanos_portal_block",
                    () -> new BlockItem(THANOS_PORTAL_BLOCK.get(),
                            new Item.Properties().tab(net.minecraft.item.ItemGroup.TAB_MISC)));
}
