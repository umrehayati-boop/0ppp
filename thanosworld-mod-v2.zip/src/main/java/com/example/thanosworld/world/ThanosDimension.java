package com.example.thanosworld.world;

import com.example.thanosworld.ThanosMod;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.util.RegistryKey;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.registry.Registry;
import net.minecraft.world.World;
import net.minecraft.world.server.ServerWorld;

public class ThanosDimension {

    public static final RegistryKey<World> THANOS_WORLD =
            RegistryKey.create(Registry.DIMENSION_REGISTRY,
                    new ResourceLocation(ThanosMod.MOD_ID, "thanos_world"));

    public static void register() {
        ThanosMod.LOGGER.info("Thanos World dimension kaydedildi!");
    }

    public static void teleportToThanos(ServerPlayerEntity player) {
        ServerWorld thanosWorld = player.getServer().getLevel(THANOS_WORLD);

        if (thanosWorld != null) {
            // Thanos dünyasına ışınla
            player.teleportTo(thanosWorld,
                    player.getX(), 100, player.getZ(),
                    player.yRot, player.xRot);
        } else {
            // Boyut bulunamazsa End'e gönder (yedek)
            ServerWorld end = player.getServer().getLevel(World.END);
            if (end != null) {
                player.teleportTo(end,
                        player.getX(), 64, player.getZ(),
                        player.yRot, player.xRot);
            }
            ThanosMod.LOGGER.warn("Thanos World bulunamadı! End'e gönderildi.");
        }
    }

    public static void teleportToOverworld(ServerPlayerEntity player) {
        ServerWorld overworld = player.getServer().getLevel(World.OVERWORLD);
        if (overworld != null) {
            player.teleportTo(overworld,
                    player.getX(), 100, player.getZ(),
                    player.yRot, player.xRot);
        }
    }
}
