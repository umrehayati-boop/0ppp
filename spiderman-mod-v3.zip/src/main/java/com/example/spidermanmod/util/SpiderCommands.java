package com.example.spidermanmod.util;

import com.example.spidermanmod.events.SpiderEventHandler;
import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.command.CommandSource;
import net.minecraft.command.Commands;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.util.text.TextFormatting;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import com.example.spidermanmod.SpiderManMod;

@Mod.EventBusSubscriber(modid = SpiderManMod.MOD_ID)
public class SpiderCommands {

    @SubscribeEvent
    public static void onRegisterCommands(RegisterCommandsEvent event) {
        CommandDispatcher<CommandSource> dispatcher = event.getDispatcher();

        // /web komutu - ağ fırlat
        dispatcher.register(Commands.literal("web")
                .executes(ctx -> {
                    if (ctx.getSource().getEntity() instanceof ServerPlayerEntity) {
                        ServerPlayerEntity player = (ServerPlayerEntity) ctx.getSource().getEntity();
                        SpiderEventHandler.shootWeb(player, player.level);
                    }
                    return 1;
                }));

        // /webmode komutu - mod değiştir
        dispatcher.register(Commands.literal("webmode")
                .executes(ctx -> {
                    if (ctx.getSource().getEntity() instanceof ServerPlayerEntity) {
                        ServerPlayerEntity player = (ServerPlayerEntity) ctx.getSource().getEntity();
                        SpiderEventHandler.cycleWebMode(player);
                    }
                    return 1;
                }));

        // /spiderman komutu - yardım göster
        dispatcher.register(Commands.literal("spiderman")
                .executes(ctx -> {
                    CommandSource src = ctx.getSource();
                    src.sendSuccess(new StringTextComponent(TextFormatting.RED + "=== Spider-Man Mod Komutları ==="), false);
                    src.sendSuccess(new StringTextComponent(TextFormatting.YELLOW + "/web" + TextFormatting.WHITE + " - Ağ fırlat"), false);
                    src.sendSuccess(new StringTextComponent(TextFormatting.YELLOW + "/webmode" + TextFormatting.WHITE + " - Ağ modunu değiştir (4 mod var)"), false);
                    src.sendSuccess(new StringTextComponent(TextFormatting.AQUA + "Ağ Modları:"), false);
                    src.sendSuccess(new StringTextComponent(TextFormatting.GREEN + "  1: Normal Ağ - Yavaşlatır"), false);
                    src.sendSuccess(new StringTextComponent(TextFormatting.BLUE + "  2: Sallanma Ağı - Uzağa fırlar"), false);
                    src.sendSuccess(new StringTextComponent(TextFormatting.YELLOW + "  3: Ağ Topu - Güçlü yavaşlatır"), false);
                    src.sendSuccess(new StringTextComponent(TextFormatting.RED + "  4: Tuzak Ağı - Tamamen durdurur"), false);
                    src.sendSuccess(new StringTextComponent(TextFormatting.GRAY + "Mutant Örümceği kullan veya kostümü giy!"), false);
                    return 1;
                }));
    }
}
