package com.example.spidermanmod.entity;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.projectile.ProjectileItemEntity;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.network.IPacket;
import net.minecraft.potion.EffectInstance;
import net.minecraft.potion.Effects;
import net.minecraft.util.math.EntityRayTraceResult;
import net.minecraft.util.math.BlockRayTraceResult;
import net.minecraft.world.World;
import net.minecraftforge.fml.network.NetworkHooks;

public class WebProjectile extends ProjectileItemEntity {

    private int webMode; // 0=Normal, 1=Sallanma yok sadece atar, 2=Top, 3=Tuzak

    public WebProjectile(EntityType<? extends WebProjectile> type, World world) {
        super(type, world);
    }

    public WebProjectile(EntityType<? extends WebProjectile> type, LivingEntity thrower, World world, int mode) {
        super(type, thrower, world);
        this.webMode = mode;
    }

    @Override
    protected Item getDefaultItem() {
        return Items.COBWEB; // varsayılan görsel
    }

    @Override
    protected void onHitEntity(EntityRayTraceResult result) {
        super.onHitEntity(result);
        if (!level.isClientSide && result.getEntity() instanceof LivingEntity) {
            LivingEntity target = (LivingEntity) result.getEntity();
            switch (webMode) {
                case 0: // Normal ağ - yavaşlatır
                    target.addEffect(new EffectInstance(Effects.MOVEMENT_SLOWDOWN, 100, 3));
                    break;
                case 2: // Ağ topu - uzun süre yavaşlatır
                    target.addEffect(new EffectInstance(Effects.MOVEMENT_SLOWDOWN, 200, 5));
                    target.addEffect(new EffectInstance(Effects.WEAKNESS, 100, 2));
                    break;
                case 3: // Tuzak - tamamen durdurur
                    target.addEffect(new EffectInstance(Effects.MOVEMENT_SLOWDOWN, 160, 10));
                    target.addEffect(new EffectInstance(Effects.JUMP, 160, -10));
                    break;
            }
            // Ağ bloğu spawn et hedefe yakın
            if (!level.isClientSide) {
                level.setBlock(result.getEntity().blockPosition(), net.minecraft.block.Blocks.COBWEB.defaultBlockState(), 3);
            }
        }
    }

    @Override
    protected void onHitBlock(BlockRayTraceResult result) {
        super.onHitBlock(result);
        if (!level.isClientSide) {
            // Bloğa çarptığında ağ bırak
            net.minecraft.util.math.BlockPos pos = result.getBlockPos().relative(result.getDirection());
            if (level.isEmptyBlock(pos)) {
                level.setBlock(pos, net.minecraft.block.Blocks.COBWEB.defaultBlockState(), 3);
            }
        }
        this.remove();
    }

    @Override
    public IPacket<?> getAddEntityPacket() {
        return NetworkHooks.getEntitySpawningPacket(this);
    }
}
