package com.example.spidermanmod;

import com.example.spidermanmod.capabilities.SpiderCapability;
import com.example.spidermanmod.entity.ModEntities;
import com.example.spidermanmod.events.SpiderEventHandler;
import com.example.spidermanmod.items.ModItems;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Mod(SpiderManMod.MOD_ID)
public class SpiderManMod {
    public static final String MOD_ID = "spidermanmod";
    public static final Logger LOGGER = LogManager.getLogger();

    public SpiderManMod() {
        ModItems.ITEMS.register(FMLJavaModLoadingContext.get().getModEventBus());
        ModEntities.ENTITIES.register(FMLJavaModLoadingContext.get().getModEventBus());
        FMLJavaModLoadingContext.get().getModEventBus().addListener(this::setup);
        MinecraftForge.EVENT_BUS.register(SpiderEventHandler.class);
    }

    private void setup(final FMLCommonSetupEvent event) {
        SpiderCapability.register();
        LOGGER.info("=================================");
        LOGGER.info("  Spider-Man Mod Yüklendi!");
        LOGGER.info("  Sam Raimi Kostümü Hazır!");
        LOGGER.info("  /spiderman komutu ile başla!");
        LOGGER.info("=================================");
    }
}
