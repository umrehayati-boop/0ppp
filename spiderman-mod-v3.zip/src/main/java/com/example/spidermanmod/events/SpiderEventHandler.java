package com.example.spidermanmod.events;

import com.example.spidermanmod.SpiderManMod;
import com.example.spidermanmod.capabilities.SpiderCapability;
import com.example.spidermanmod.capabilities.SpiderCapabilityProvider;
import com.example.spidermanmod.entity.ModEntities;
import com.example.spidermanmod.entity.WebProjectile;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.potion.EffectInstance;
import net.minecraft.potion.Effects;
import net.minecraft.util.DamageSource;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.world.World;
import net.minecraftforge.common.capabilities.ICapabilityProvider;
import net.minecraftforge.event.AttachCapabilitiesEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingFallEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = SpiderManMod.MOD_ID)
public class SpiderEventHandler {

    // Her oyuncu için ağ cooldown takibi
    private static final java.util.HashMap<java.util.UUID, Integer> webCooldowns = new java.util.HashMap<>();
    private static final java.util.HashMap<java.util.UUID, Integer> climbCooldowns = new java.util.HashMap<>();

    // Capability'yi oyuncuya ekle
    @SubscribeEvent
    public static void onAttachCapabilities(AttachCapabilitiesEvent<Entity> event) {
        if (event.getObject() instanceof PlayerEntity) {
            SpiderCapabilityProvider provider = new SpiderCapabilityProvider();
            event.addCapability(new ResourceLocation(SpiderManMod.MOD_ID, "spider_data"), provider);
            event.addListener(provider::invalidate);
        }
    }

    // Oyuncu ölünce yeniden doğduğunda capability'yi kopyala (güçler kalıcı kalır)
    @SubscribeEvent
    public static void onPlayerClone(PlayerEvent.Clone event) {
        PlayerEntity original = event.getOriginal();
        PlayerEntity newPlayer = event.getPlayer();

        if (!event.isWasDeath()) return;
        SpiderCapability.getSpiderData(original).ifPresent(oldData -> {
            SpiderCapability.getSpiderData(newPlayer).ifPresent(newData -> {
                newData.setPowers(oldData.hasPowers());
                newData.setWebMode(oldData.getWebMode());
            });
        });
    }

    // Her tick: duvar tırmanma + güç efektleri
    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        PlayerEntity player = event.player;
        if (player.level.isClientSide) return;

        SpiderCapability.getSpiderData(player).ifPresent(data -> {
            if (!data.hasPowers()) return;

            // Süper güç efektleri (sürekli)
            player.addEffect(new EffectInstance(Effects.DAMAGE_BOOST, 40, 2, false, false));       // Güç +3
            player.addEffect(new EffectInstance(Effects.MOVEMENT_SPEED, 40, 1, false, false));     // Hız +2
            player.addEffect(new EffectInstance(Effects.JUMP, 40, 2, false, false));               // Zıplama +3
            player.addEffect(new EffectInstance(Effects.DAMAGE_RESISTANCE, 40, 1, false, false));  // Hasar direnci

            // Duvar tırmanma: oyuncu bir bloğa yakın + atlama basılı + düşüyor
            handleWallClimbing(player);
        });
    }

    private static void handleWallClimbing(PlayerEntity player) {
        boolean inAir = !player.isOnGround();
        if (!inAir) return;

        BlockPos pos = player.blockPosition();
        boolean nearWall = false;
        for (net.minecraft.util.Direction dir : new net.minecraft.util.Direction[]{
                net.minecraft.util.Direction.NORTH,
                net.minecraft.util.Direction.SOUTH,
                net.minecraft.util.Direction.EAST,
                net.minecraft.util.Direction.WEST}) {
            BlockPos checkPos = pos.relative(dir);
            if (!player.level.isEmptyBlock(checkPos) || !player.level.isEmptyBlock(checkPos.above())) {
                nearWall = true;
                break;
            }
        }

        if (nearWall) {
            Vector3d motion = player.getDeltaMovement();
            if (motion.y < 0) {
                player.setDeltaMovement(motion.x, Math.max(motion.y, -0.1), motion.z);
            }
            player.fallDistance = 0;
        }
    }

    // Düşme hasarını engelle
    @SubscribeEvent
    public static void onFall(LivingFallEvent event) {
        if (event.getEntityLiving() instanceof PlayerEntity) {
            PlayerEntity player = (PlayerEntity) event.getEntityLiving();
            SpiderCapability.getSpiderData(player).ifPresent(data -> {
                if (data.hasPowers()) {
                    event.setCanceled(true); // Düşme hasarı yok!
                }
            });
        }
    }

    // Ağ modunu değiştir komutu için (R tuşu komutu)
    public static void cycleWebMode(PlayerEntity player) {
        SpiderCapability.getSpiderData(player).ifPresent(data -> {
            if (!data.hasPowers()) {
                player.sendMessage(new StringTextComponent(
                        TextFormatting.RED + "Önce örümcek güçleri kazanmalısın!"), player.getUUID());
                return;
            }
            int newMode = (data.getWebMode() + 1) % 4;
            data.setWebMode(newMode);
            String[] modeNames = {
                "§aMode 1: §fNormal Ağ §7(Yavaşlatır)",
                "§bMode 2: §fSallanma Ağı §7(Uzağa fırlar)",
                "§eMode 3: §fAğ Topu §7(Güçlü yavaşlatır)",
                "§cMode 4: §fTuzak Ağı §7(Tamamen durdurur)"
            };
            player.sendMessage(new StringTextComponent(
                    TextFormatting.AQUA + "🕸 Ağ Modu: " + modeNames[newMode]), player.getUUID());
        });
    }

    // Ağ fırlat
    public static void shootWeb(PlayerEntity player, World world) {
        SpiderCapability.getSpiderData(player).ifPresent(data -> {
            if (!data.hasPowers()) return;

            // Cooldown kontrolü
            int cooldown = webCooldowns.getOrDefault(player.getUUID(), 0);
            if (cooldown > 0) {
                player.sendMessage(new StringTextComponent(
                        TextFormatting.GRAY + "Ağ yeniliyor... (" + cooldown + " tick)"), player.getUUID());
                return;
            }

            int mode = data.getWebMode();
            if (!world.isClientSide) {
                WebProjectile web = new WebProjectile(
                        ModEntities.WEB_PROJECTILE.get(), player, world, mode);

                // Moduna göre hız ayarla
                float speed = (mode == 1) ? 3.0f : 1.8f; // Sallanma modu daha hızlı
                float inaccuracy = (mode == 2) ? 0.5f : 0.1f; // Ağ topu hafif dağınık

                web.shootFromRotation(player, player.xRot, player.yRot, 0.0f, speed, inaccuracy);
                world.addFreshEntity(web);

                // Cooldown set et
                webCooldowns.put(player.getUUID(), mode == 2 ? 25 : 15);
            }
        });
    }

    // Cooldown azalt her tick
    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        webCooldowns.replaceAll((uuid, cd) -> Math.max(0, cd - 1));
        webCooldowns.entrySet().removeIf(e -> e.getValue() <= 0);
    }
}
