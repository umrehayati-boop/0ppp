package com.example.spidermanmod.capabilities;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.nbt.CompoundNBT;
import net.minecraft.util.Direction;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.CapabilityInject;
import net.minecraftforge.common.capabilities.CapabilityManager;
import net.minecraftforge.common.util.LazyOptional;

public class SpiderCapability {

    @CapabilityInject(ISpiderData.class)
    public static Capability<ISpiderData> SPIDER_CAP = null;

    public static void register() {
        CapabilityManager.INSTANCE.register(ISpiderData.class, new SpiderStorage(), SpiderData::new);
    }

    public static LazyOptional<ISpiderData> getSpiderData(PlayerEntity player) {
        return player.getCapability(SPIDER_CAP);
    }

    // Web Modları: 0=Normal Ağ, 1=Sallanma, 2=Ağ Topu, 3=Tuzak Ağı
    public interface ISpiderData {
        boolean hasPowers();
        void setPowers(boolean hasPowers);
        int getWebMode();
        void setWebMode(int mode);
        CompoundNBT serializeNBT();
        void deserializeNBT(CompoundNBT nbt);
    }

    public static class SpiderData implements ISpiderData {
        private boolean hasPowers = false;
        private int webMode = 0;

        @Override public boolean hasPowers() { return hasPowers; }
        @Override public void setPowers(boolean hasPowers) { this.hasPowers = hasPowers; }
        @Override public int getWebMode() { return webMode; }
        @Override public void setWebMode(int mode) { this.webMode = mode % 4; }

        @Override
        public CompoundNBT serializeNBT() {
            CompoundNBT nbt = new CompoundNBT();
            nbt.putBoolean("hasPowers", hasPowers);
            nbt.putInt("webMode", webMode);
            return nbt;
        }

        @Override
        public void deserializeNBT(CompoundNBT nbt) {
            hasPowers = nbt.getBoolean("hasPowers");
            webMode = nbt.getInt("webMode");
        }
    }

    public static class SpiderStorage implements Capability.IStorage<ISpiderData> {
        @Override
        public CompoundNBT writeNBT(Capability<ISpiderData> capability, ISpiderData instance, Direction side) {
            return instance.serializeNBT();
        }

        @Override
        public void readNBT(Capability<ISpiderData> capability, ISpiderData instance, Direction side, net.minecraft.nbt.INBT nbt) {
            if (nbt instanceof CompoundNBT) {
                instance.deserializeNBT((CompoundNBT) nbt);
            }
        }
    }
}
