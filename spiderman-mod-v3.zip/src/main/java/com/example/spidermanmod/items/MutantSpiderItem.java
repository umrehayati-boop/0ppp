package com.example.spidermanmod.items;

import com.example.spidermanmod.capabilities.SpiderCapability;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.world.World;

import javax.annotation.Nullable;
import java.util.List;

public class MutantSpiderItem extends Item {

    public MutantSpiderItem() {
        super(new Item.Properties()
                .tab(net.minecraft.item.ItemGroup.TAB_MISC)
                .stacksTo(1));
    }

    @Override
    public ActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
        if (!world.isClientSide) {
            SpiderCapability.getSpiderData(player).ifPresent(data -> {
                if (!data.hasPowers()) {
                    data.setPowers(true);
                    // Elytra gibi görünüm için title effect
                    player.sendMessage(new StringTextComponent(
                            TextFormatting.DARK_RED + "☠ " +
                            TextFormatting.RED + "Mutant örümcek seni ısırdı!" +
                            TextFormatting.DARK_RED + " ☠"), player.getUUID());
                    player.sendMessage(new StringTextComponent(
                            TextFormatting.GOLD + "DNA'n değişiyor... Örümcek güçleri kalıcı olarak aktif!"), player.getUUID());
                    player.sendMessage(new StringTextComponent(
                            TextFormatting.GREEN + "✔ Duvar tırmanma aktif!"), player.getUUID());
                    player.sendMessage(new StringTextComponent(
                            TextFormatting.GREEN + "✔ Ağ atma aktif! [R] ile mod değiştir"), player.getUUID());
                    player.sendMessage(new StringTextComponent(
                            TextFormatting.GREEN + "✔ Süper güç aktif!"), player.getUUID());
                    // Örümceği tüket
                    player.getItemInHand(hand).shrink(1);
                } else {
                    player.sendMessage(new StringTextComponent(
                            TextFormatting.YELLOW + "Zaten örümcek güçlerine sahipsin!"), player.getUUID());
                }
            });
        }
        return ActionResult.success(player.getItemInHand(hand));
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable World world, List<ITextComponent> tooltip, ITooltipFlag flag) {
        tooltip.add(new StringTextComponent(TextFormatting.DARK_RED + "Radyoaktif mutant örümcek!"));
        tooltip.add(new StringTextComponent(TextFormatting.GRAY + "Sağ tık: Örümcek seni ısırır"));
        tooltip.add(new StringTextComponent(TextFormatting.RED + "UYARI: Kalıcı mutasyon!"));
        tooltip.add(new StringTextComponent(TextFormatting.YELLOW + "Kostüm giymene gerek yok."));
    }
}
