package com.example.spidermanmod.items;

import com.example.spidermanmod.SpiderManMod;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraft.item.Item;

public class ModItems {

    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, SpiderManMod.MOD_ID);

    public static final RegistryObject<Item> SPIDER_SUIT =
            ITEMS.register("spider_suit", SpiderSuitItem::new);

    public static final RegistryObject<Item> MUTANT_SPIDER =
            ITEMS.register("mutant_spider", MutantSpiderItem::new);

    public static void registerItems(net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent event) {
        // item setup if needed
    }
}
